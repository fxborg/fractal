#include "higuchi.h"
#include <math.h>
#include <cmath>
#include <iostream>
EXPORT CHiguchi * __stdcall Create(
	const unsigned int length,
	const unsigned int k_max)
{
	return new CHiguchi(length, k_max);
}

EXPORT void __stdcall Destroy(CHiguchi * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CHiguchi * instance, const int x, const double y, const time_t t0, const time_t t1)
{
	return instance->push(x, y, t0, t1);
}

EXPORT double __stdcall Calculate(CHiguchi * instance)
{
	return instance->calculate();	
}



CHiguchi::CHiguchi(const unsigned int length, const unsigned int k_max) :
	m_length(minmax(length,64,8000)),
	m_k_max(minmax(k_max, 10, int(0.5*length))),
	m_series(CSeries(m_length+1))
{
}


int CHiguchi::push(const int x, const double y, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		result = m_series.push(x, y, t0, t1);

	}
	catch (...)
	{
		result = -9999;
	}

	return result;
}

double CHiguchi::calculate()
{
	if (!m_series.is_adding())return -1.0;
	const std::deque<double> & series = m_series.get_stats_series();
	unsigned int N = series.size()-1;
	double nm1 = N - 1.0;
	if (N < m_length)return 0.0;
	std::vector<double> Lmk(m_k_max);
	
	double sum = 0.0;
	for(auto it = series.cbegin();it!= series.cend()-2;it++)
	{
		sum += std::abs(*(it + 1) - *it);
	}
	Lmk[0] = sum;

	for (int k = 2; k <= (int)m_k_max; k++)
	{
		double lmk_total=0.0;
		for (int m = 1; m <= k; m++)
		{
			unsigned int i_end = int((N - m) / k);
			double lmk_sum = 0.0;
			auto mit = series.cbegin() + (m - 1);
			for (unsigned int i = 1; i <= i_end; i++)
			{
				lmk_sum += abs(*(mit + (i*k))  - *(mit + ((i-1)*k)));
			}

			double ng = nm1 / (i_end * k);
			lmk_total += lmk_sum * ng / k;
		}
		Lmk[k-1] = lmk_total / k;
	}
	Stats stat = Stats();
	for (int k = 1; k <= (int)m_k_max; k++)
	{
		stat.push(1, std::log(1.0 / k), std::log(Lmk[k - 1]));
	}
	return stat.slope();
}

unsigned int CHiguchi::minmax(const unsigned int n, const unsigned int min, const unsigned int max)
{
	return std::max(min,std::min(max,n));
}
