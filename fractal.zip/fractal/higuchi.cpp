#include "higuchi.h"
#include <math.h>
#include <cmath>
#include <iostream>
EXPORT CHiguchi * __stdcall Create(const unsigned int length, const unsigned int k1, const unsigned int k2)
{
	return new CHiguchi(length, k1, k2);
}

EXPORT void __stdcall Destroy(CHiguchi * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CHiguchi * instance, const int x, const double y, const time_t t0, const time_t t1)
{
	return instance->push(x, y, t0, t1);
}
EXPORT bool __stdcall Calculate(CHiguchi* instance, double & slope1, double & corr1, double & slope2, double & corr2)
{
	return instance->calculate(slope1,corr1,slope2,corr2);	
}

CHiguchi::CHiguchi(const unsigned int length, const unsigned int k1, const unsigned int k2) :
	m_length(minmax(length,50,2000)),
	m_k_min(minmax(k1, 4,		int(0.5*m_length))),
	m_k_max(minmax(k2, m_k_min, int(0.5*m_length))),
	m_series(CSeries(m_length+1))
{
}

int CHiguchi::push(const int x, const double y, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		result = m_series.push(x, y, t0, t1);

	}
	catch (...)
	{
		result = -9999;
	}

	return result;
}

bool CHiguchi::calculate(double & slope1, double & corr1, double & slope2, double & corr2)
{
	if (!m_series.is_adding())return false;
	const std::deque<double> & series = m_series.get_stats_series();
	unsigned int N = series.size()-1;
	double nm1 = N - 1.0;
	if (N < m_length)return 0.0;
	std::vector<double> Lmk(m_k_max);
	
	double sum = 0.0;
	for(auto it = series.cbegin();it!= series.cend()-2;it++)
	{
		sum += std::abs(*(it + 1) - *it);
	}
	Lmk[0] = sum;

	for (int k = 2; k <= (int)m_k_max; k++)
	{
		double lmk_total=0.0;
		for (int m = 1; m <= k; m++)
		{
			unsigned int i_end = int((N - m) / k);
			double lmk_sum = 0.0;
			auto mit = series.cbegin() + (m - 1);
			for (unsigned int i = 1; i <= i_end; i++)
			{
				lmk_sum += abs(*(mit + (i*k))  - *(mit + ((i-1)*k)));
			}

			double ng = nm1 / (i_end * k);
			lmk_total += lmk_sum * ng / k;
		}
		Lmk[k-1] = lmk_total / k;
	}
	std::vector<std::pair<double, double>> data;

	for (unsigned int k = 1; k <= m_k_max; k++)
	{
		data.emplace_back(std::log(1.0 / k), std::log(Lmk[k - 1]));
	}
	

	return analyse(data, slope1, corr1, slope2, corr2);

}


bool CHiguchi::analyse(const std::vector<std::pair<double, double>> & data, double & slope1, double & corr1, double & slope2, double & corr2)
{
	if (data.size() < 2) return false;
	Stats stat = Stats();
	for (unsigned int i = 0; i < m_k_min; i++)
	{
		stat += Stats(1, data[i].first, data[i].second);
	}
	slope1 = stat.slope();
	corr1 = stat.corr();
	for (unsigned int i = m_k_min ; i < m_k_max; i++)
	{
		stat += Stats(1, data[i].first, data[i].second);
	}
	slope2 = stat.slope();
	corr2 = stat.corr();
	return true;
}

//bool CHiguchi::find_slope(const std::vector<std::pair<double, double>> & data, double & slope, double & corr,int &best_k)
//{
//	if (data.size() < 2) return false;
//	//--- �S�f�[�^�̓��v�ʂ��v�Z
//	Stats stat1 = Stats();
//	for (unsigned int i = 0; i<data.size(); i++)
//	{
//		stat1 += Stats(1, data[i].first, data[i].second);
//	}
//	//--- �S�f�[�^�̃X���[�v�Ƒ��֌W�����Z�b�g
//	double best_err = stat1.residuals();
//	corr = stat1.corr();
//	slope = stat1.slope();
//	best_k = m_k_max;
//	if (data.size() < 10) return true;
//
//	Stats stat2 = Stats();
//	unsigned int tail = data.size() - 1;
//
//	//--- �Q���������ꍇ�̌덷���ŏ��ƂȂ�ʒu���v�Z���A���̎��̃X���[�v�Ƒ��֌W�����Z�b�g����B
//	for (unsigned int i = tail;i >=m_k_min; i--)
//	{
//		stat1 -= Stats(1, data[i].first, data[i].second);
//		stat2 += Stats(1, data[i].first, data[i].second);
//		if (tail - 2 < i)continue;
//		double err = stat1.residuals() + stat2.residuals();
//		if (err < best_err)
//		{
//			best_k = i - 1;
//			best_err = err;
//			corr = stat1.corr();
//			slope = stat1.slope();
//
//		}
//	}
//	return true;
//}

unsigned int CHiguchi::minmax(const unsigned int n, const unsigned int min, const unsigned int max)
{
	return std::max(min, std::min(max, n));
}
