#define EXPORT  extern "C" // __declspec(dllexport)  
#include <deque> 
#include <vector> 
#include <numeric>
#include <cmath>
#include <algorithm>
#include<iterator>
#include "series.h"
#include "stats.h"
class CHiguchi
{
public:
	// �R���X�g���N�^

	explicit CHiguchi(const unsigned int length, const unsigned  int k1, const unsigned  int k2);

	int push(const int x, const double y, const time_t t0, const time_t t1);
	bool calculate(double & slope1, double & corr1, double & slope2, double & corr2);


private:
	unsigned int minmax(const unsigned int n, const  unsigned int min, const  unsigned int max);
	bool CHiguchi::analyse(const std::vector<std::pair<double, double>> & data, double & slope1, double & corr1, double & slope2, double & corr2);
//	bool find_slope(const std::vector<std::pair<double,double>> &data, double &slope,double &corr, int &best_k);
	const unsigned int m_length;
	const unsigned int m_k_min;
	const unsigned int m_k_max;
	CSeries m_series;
};

//--- �C���X�^���X�𐶐�
EXPORT CHiguchi * __stdcall Create(const unsigned int length, const unsigned int k1, const unsigned int  k2);
//--- �C���X�^���X��j��
EXPORT void __stdcall Destroy(CHiguchi* instance);
//--- �C���X�^���X�o�R��push���\�b�h���R�[��
EXPORT int __stdcall Push(CHiguchi* instance, const int x, const double y, const time_t t0, const time_t t1);
//--- �\���l���v�Z
EXPORT bool __stdcall Calculate(CHiguchi* instance , double & slope1, double & corr1, double & slope2, double & corr2);

