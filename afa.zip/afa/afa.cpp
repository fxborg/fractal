#include "afa.h"


EXPORT CAfa * __stdcall Create(	const unsigned int length,	 const unsigned int order, const unsigned int scale1, const unsigned int scale2)
{
	return new CAfa(length, order, scale1,scale2);
}

EXPORT void __stdcall Destroy(CAfa * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CAfa * instance, const int x, const double y, const time_t t0, const time_t t1)
{
	return instance->push(x, y, t0, t1);
}

EXPORT bool __stdcall Calculate(CAfa * instance, double &slope1, double &corr1, double &slope2,double &corr2)
{
	return instance->calculate(slope1,corr1,slope2,corr2);
}

CAfa::CAfa(const unsigned int length,const unsigned int order, const unsigned int scale1, const unsigned int scale2) :
	m_length(validate_length(length)),
	m_step(0.5),
	m_order(validate_order(order)),
	m_scale1(validate_scale1(scale1)),
	m_scale2(validate_scale2(scale2)),
	m_series(CSeries(m_length + 1))
{

	// �E�C���h�E�T�C�Y�̏�����
	int imax = int(std::round(std::log2(m_length)))-1;
	unsigned int i = 0;
	for (double m = 2; m < imax; m += m_step)
		{
		unsigned int w = int(round(pow(2, m) + 1));
		if ((w % 2) == 0) w += 1u;
		i++;
		if (i > m_scale2)break;
		// �Z�O�����g�̒ǉ�	
		m_segments.emplace_back(unsigned int((w-1)*0.5));
		// �g�����h�t�B���^�̒ǉ�
		m_filters.emplace_back(w, m_order);
	}

	// �L���b�V���̏�����
	for (auto it = m_segments.begin(); it != m_segments.end(); it++)
	{
		m_cache.insert(std::make_pair(*it, CCache(*it, m_length)));
	}

}


int CAfa::push(const int x, const double y, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		result = m_series.push(x, y, t0, t1);

	}
	catch (...)
	{
		return -9999;
	}

	if (!m_series.is_adding())return -1;
	std::deque<double> series = m_series.get_series();
	for (unsigned int i = 0; i < m_segments.size(); i++)
	{

		unsigned int step = m_segments[i];
		unsigned int w = step * 2 + 1;
		unsigned int len = step * 3 + 1;
		unsigned int sz = series.size();
		if (sz - 1 < len) continue;
		int offset = sz - len - 1;
		std::vector<double> data;
		std::copy(series.cbegin() + offset, series.cend() - 1, std::back_inserter(data));
		std::vector <double> trend;
		double v1 = 0.0;
		double v2 = 0.0;
		if (m_filters[i].fit(data, trend)) {
			volatility(data, trend, step, v1, v2);
		}

		// �L���b�V���ɒǉ�
		
		m_cache[step].set(x - step, v1);
		m_cache[step].set(x, v2);

		
	}
	return result;

}

bool CAfa::calculate(double &slope1, double &corr1, double &slope2, double &corr2)
{
	int x = m_series.prev_x();

	std::vector<std::pair<double,double>> fq;

	for (unsigned int i = 0; i < m_segments.size(); i++)
	{
		unsigned int step = m_segments[i];
		unsigned int w = step * 2 + 1;
	
		double v = m_cache[step].calc_fractal(x);
		if (v == 0)break;
		fq.emplace_back( log2(w), log2(v));
	}
	Stats stat = Stats();
	for (unsigned int i = 0; i < m_scale1 && i< fq.size(); i++)
	{
		stat += Stats(1, fq[i].first, fq[i].second);
	}
	slope1 = stat.slope();
	corr1 = stat.corr();
	for (unsigned i = m_scale1; i < m_scale2 && i< fq.size(); i++)
	{
		
		stat += Stats(1, fq[i].first, fq[i].second);
	}
	slope2 = stat.slope();
	corr2 = stat.corr();

	return true;
}
void CAfa::volatility(std::vector<double> &y, std::vector<double> &y_hat, const unsigned int step, double &v1,double &v2)
{
	unsigned int sz = step*2;
	unsigned int from_y = y.size() - sz;
	unsigned int from_y_hat = y_hat.size() - sz;

	v1 = 0.0;
	for (unsigned int i = 0; i < step; i++)
	{
		v1 += abs(y[from_y + i] - y_hat[from_y_hat + i]);
	}

	v2 = 0.0;
	for (unsigned int i = step; i < sz; i++)
	{
		v2 += abs(y[from_y + i] - y_hat[from_y_hat + i]);
	}
}

bool CAfa::get_results(const unsigned int idx, double &y)
{
	if (m_results.size() <= idx) return false;
	y = m_results[idx];
	return true;
}


unsigned int CAfa::validate_length(const unsigned int len)
{
	unsigned int l = int(pow(2, int(log2(len))));
	return std::max(16u, std::min(2048u, l));
}

unsigned int  CAfa::validate_order(const unsigned int order)
{
	return std::min(3u, std::max(1u, order));
}


unsigned int CAfa::validate_scale1(const unsigned int scale1)
{

	int imax = int(std::round(std::log2(m_length))) - 1;
	unsigned int i = 0;
	for (double m = 2.0; m < imax; m += m_step)
	{
		unsigned int w = int(round(pow(2, m) + 1));
		if ((w % 2) == 0) w += 1u;
		i++;
		if (w > scale1) break;
	}
	return i;
}


unsigned int CAfa::validate_scale2(const unsigned int scale2)
{

	int imax = int(std::round(std::log2(m_length))) - 1;
	unsigned int i = 0;
	for (double m = 2.0; m < imax; m += m_step)
	{
		unsigned int w = int(round(pow(2, m) + 1));
		if ((w % 2) == 0) w += 1u;
		i++;
		if (w > scale2) break;
	}
	
	return std::max(i,m_scale1);
}


