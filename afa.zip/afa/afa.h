#define EXPORT  extern "C" // __declspec(dllexport)  
#include <deque> 
#include <vector> 
#include <iterator> 
#include <numeric>
#include <cmath>
#include <algorithm>
#include<iterator>
#include <unordered_map>
#include "series.h"
#include "trend.h"
#include "cache.h"
#include "stats.h"
class CAfa
{
public:
	// �R���X�g���N�^
	explicit CAfa(const unsigned int length, const unsigned int order, const unsigned int scale1, const unsigned int scale2);

	int push(const int x, const double y, const time_t t0, const time_t t1);

	bool calculate( double &slope1, double &corr1, double &slope2, double &corr2);

	bool get_results(unsigned int idx,double & y);

private:
	unsigned int validate_length(const  unsigned int len);
	unsigned int validate_order(const  unsigned int order);
	unsigned int validate_scale1(const unsigned int scale1);
	unsigned int validate_scale2(const unsigned int scale2);


	void CAfa::volatility(std::vector<double> &y, std::vector<double> &y_hat, const unsigned int step, double &v1, double &v2);

	const unsigned int m_length;
	const double m_step;
	const unsigned int m_order;
	const unsigned int m_scale1;
	const unsigned int m_scale2;

	CSeries m_series;

	std::vector<unsigned int> m_segments;
	std::vector<CTrend> m_filters;
	std::unordered_map<unsigned int, CCache> m_cache;
	std::vector<double>m_results;
};

//--- �C���X�^���X�𐶐�
EXPORT CAfa * __stdcall Create(const unsigned int length, const unsigned int order, const unsigned int scale1, const unsigned int scale2);
//--- �C���X�^���X��j��
EXPORT void __stdcall Destroy(CAfa* instance);
//--- �C���X�^���X�o�R��push���\�b�h���R�[��
EXPORT int __stdcall Push(CAfa* instance, const int x, const double y, const time_t t0, const time_t t1);
//--- �\���l���v�Z
EXPORT bool  __stdcall Calculate(CAfa* instance, double &slope1, double &corr1, double &slope2, double &corr2);
