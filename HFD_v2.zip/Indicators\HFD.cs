// 
// Copyright (C) 2016, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using System.Runtime.InteropServices;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion
// This namespace holds indicators in this folder and is required. Do not change it.

namespace NinjaTrader.NinjaScript.Indicators
{

	/// <summary>
	/// The Average True Range (HFD) is a measure of volatility. It was introduced by Welles Wilder 
	/// in his book 'New Concepts in Technical Trading Systems' and has since been used as a component 
	/// of many indicators and trading systems.
	/// </summary>
	public class HFD : Indicator
	{
        [DllImport("fractal.dll", CallingConvention = CallingConvention.StdCall)]
        static extern  IntPtr Create(int length,int k1,int k2,bool use_logspace,double step);
        [DllImport("fractal.dll", CallingConvention = CallingConvention.StdCall)]
        static extern int Push(IntPtr instance, int x, double y, long t0, long t1);
        [DllImport("fractal.dll", CallingConvention = CallingConvention.StdCall)]
        static extern bool Calculate(IntPtr instance, out double slope1, out double corr1, out double slope2, out double corr2);
        [DllImport("fractal.dll", CallingConvention = CallingConvention.StdCall)]
        static extern void Destroy(IntPtr instance);		
	
		private Brush opaqueDarkGrey;
		private IntPtr instance = IntPtr.Zero;
		int N;		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "Higuchi Fractal Dimension";
				Name						= "HFD";
				IsSuspendedWhileInactive	= true;
				Period						= 512;	
				K1							= 64;
				K2							= 256;
				Step						= 0.25;
				Threshold					= 0.998;
			}
			else if (State == State.Historical)
			{
				N = (int)(Math.Pow(2, Math.Round(Math.Log(Period,2))));		
				if(instance!=IntPtr.Zero) Destroy(instance);
				instance = Create(N,K1,K2,true,Step);
			}
			else if (State == State.Terminated) 
			{
				if(instance!=IntPtr.Zero) Destroy(instance);				
			}
			else if(State == State.Configure)
			{
 				 AddPlot(Brushes.Lime, "FD1");
				 AddPlot(Brushes.DodgerBlue, "FD2");				
				 AddLine(Brushes.DarkViolet,		1.5,	"Randam Walk");
				 
				 opaqueDarkGrey = new SolidColorBrush(Colors.DarkGray) {Opacity = 0.2};
				 opaqueDarkGrey.Freeze();
				
			}
		}

		protected override void OnBarUpdate()
		{
			
			if (CurrentBar < 1)return;
			int n= Push(instance,CurrentBar,Close[0],Time[0].ToBinary(),Time[1].ToBinary());
			if(n == -1 )return;
			if(n == -9999)
			{
			 Print(CurrentBar+" "+Time[0]);
			 Print(n+" ------------- Reset --------------- "+Time[0]);
			 Destroy(instance); //インスタンスを破棄
			 instance=Create(N,K1,K2,true,Step); //インスタンスを生成
			 return;
			}

 		     double fd1,fd2;
	         double corr1,corr2;
	         if(Calculate(instance,out fd1,out corr1,out fd2,out corr2))
	           {
				if(corr2<Threshold)	BackBrush = opaqueDarkGrey;
				Values[0][0]=fd1;
	            Values[1][0]=fd2;
	           }
		}

		#region Properties
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> FD1
		{
			get { return Values[0]; }
		}
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> FD2
		{
			get { return Values[1]; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Period
		{ get; set; }
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "k1", GroupName = "NinjaScriptParameters", Order = 1)]
		public int K1
		{ get; set; }
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "k2", GroupName = "NinjaScriptParameters", Order = 2)]
		public int K2
		{ get; set; }
		[Range(0.99,1.0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Threshold", GroupName = "NinjaScriptParameters", Order = 3)]
		public double Threshold
		{ get; set; }
		[Range(0.1, 1.0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "step", GroupName = "NinjaScriptParameters", Order = 4)]
		public double Step
		{ get; set; }
		#endregion
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HFD[] cacheHFD;
		public HFD HFD(int period, int k1, int k2, double threshold, double step)
		{
			return HFD(Input, period, k1, k2, threshold, step);
		}

		public HFD HFD(ISeries<double> input, int period, int k1, int k2, double threshold, double step)
		{
			if (cacheHFD != null)
				for (int idx = 0; idx < cacheHFD.Length; idx++)
					if (cacheHFD[idx] != null && cacheHFD[idx].Period == period && cacheHFD[idx].K1 == k1 && cacheHFD[idx].K2 == k2 && cacheHFD[idx].Threshold == threshold && cacheHFD[idx].Step == step && cacheHFD[idx].EqualsInput(input))
						return cacheHFD[idx];
			return CacheIndicator<HFD>(new HFD(){ Period = period, K1 = k1, K2 = k2, Threshold = threshold, Step = step }, input, ref cacheHFD);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HFD HFD(int period, int k1, int k2, double threshold, double step)
		{
			return indicator.HFD(Input, period, k1, k2, threshold, step);
		}

		public Indicators.HFD HFD(ISeries<double> input , int period, int k1, int k2, double threshold, double step)
		{
			return indicator.HFD(input, period, k1, k2, threshold, step);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HFD HFD(int period, int k1, int k2, double threshold, double step)
		{
			return indicator.HFD(Input, period, k1, k2, threshold, step);
		}

		public Indicators.HFD HFD(ISeries<double> input , int period, int k1, int k2, double threshold, double step)
		{
			return indicator.HFD(input, period, k1, k2, threshold, step);
		}
	}
}

#endregion
