#include "mfdfa.h"
EXPORT CMFDFA * __stdcall Create(
	const unsigned int length,
	const double scale_step, 
	const unsigned int scale_min, 
	const unsigned int scale_max,
	const double q_step, 
	const double q_min, 
	const double q_max)
{
	return new CMFDFA(length, scale_step, scale_min, scale_max, q_step,q_min,q_max);
}

EXPORT void __stdcall Destroy(CMFDFA * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CMFDFA * instance, const int x, const double y, const time_t t0, const time_t t1)
{
	return instance->push(x, y, t0, t1);
}

EXPORT int __stdcall Calculate(CMFDFA * instance)
{
	return instance->calculate();	
}

EXPORT bool __stdcall GetResults(
	CMFDFA * instance,
	unsigned int idx,
	double & q,
	double & Hq,
	double & tq,
	double & Dq,
	double & hq
) 
{
	return instance->get_results(idx,q,Hq,tq,Dq,hq);
}



CMFDFA::CMFDFA(const unsigned int length, 
				const double scale_step, const unsigned int scale_min, const unsigned int scale_max,
				const double q_step, const double q_min, const double q_max):
	m_length(length),
	m_series(CSeries(length+1))
{
	double n = round(log2(scale_min));
	int  max = int(std::min(scale_max, length));
	int w = int(round(std::pow(2, n)));

	while (w <= max)
	{
		m_segments.push_back(w);
		n += scale_step;
		w = int(round(std::pow(2, n)));

	}

	// �L���b�V���̏�����
	for (auto it = m_segments.begin(); it != m_segments.end(); it++)
	{
		m_caches.insert(std::make_pair(*it, CRmsCache(*it, m_length)));
	}
	// �o�b�t�@�̏�����
	for (auto it = m_segments.begin(); it != m_segments.end(); it++)
	{
		m_buffers.insert(std::make_pair(*it,std::make_pair(0,Stats())));
	}

	for(double q=q_min;q<=q_max;q+=q_step)
	{
		m_q.push_back(q);
	}

}


int CMFDFA::push(const int x, const double y, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		const std::deque<Stats> & series = m_series.get_stats_series();
		
		Stats prev_stats = (series.size() > 0)? *series.rbegin() : Stats();
		result = m_series.push(x, y, t0, t1);
		Stats new_stats = *series.rbegin();

		for (auto it = m_segments.begin(); it != m_segments.end(); it++)
		{
			unsigned int w = *it;
			if (m_series.is_adding()) 
			{
				int sz = series.size();
				//�V�K�o�[�ǉ���
				m_buffers[w].first++;
				m_buffers[w].second = m_buffers[w].second + new_stats;
				if (m_buffers[w].first > w)
				{
					//std::cout << m_buffers[w].second.x << " - " << series[(sz - (w + 1))].x << std::endl;
					m_buffers[w].second = m_buffers[w].second - series[(sz - (w+1))];
				}
			}
			else 
			{
				//���X�g�o�[�X�V��
				m_buffers[w].second = m_buffers[w].second + (new_stats - prev_stats);
			}

			/* �m�F�p*/
			//if (m_buffers[w].first > w)
			//{
			//	Stats stat = Stats();
			//	int sz = series.size();
			//	int cnt = 0;
			//	for(int i=sz-w;i<sz;i++)
			//	{
			//		cnt++;
			//		stat = stat + series[i];
			//		std::cout << series[i].x << ",";
			//	}

			//	std::cout << std::endl << m_buffers[w].first << ":" <<  x - w << "->" << x;
			//	std::cout << " " <<cnt << "===" << m_buffers[w].second.n;

			//	std::cout << " " << stat.residuals() << " === ";
			//	std::cout << m_buffers[w].second.residuals() << std::endl;
			//}
			// �L���b�V���ɒǉ�
			m_caches[w].set(x, m_buffers[w].second.residuals() / w); 
		}

	}
	catch (...)
	{
		result = -9999;
	}

	return result;
}

int CMFDFA::calculate()
{
	std::vector<double> Hq;
	std::vector<double> tq;
	int x = m_series.last_x();


	m_results.erase(m_results.begin(), m_results.end());

	for (unsigned int i = 0; i < m_q.size() ; i++)
	{
		std::vector<Stats> fq;
		double q = m_q[i];
//		std::cout << "------------------------------" << q << std::endl;
		for (auto w_it = m_segments.begin(); w_it != m_segments.end(); w_it++)
		{
			unsigned int w = *w_it;
			fq.emplace_back(1,log2(w), log2(m_caches[w].calc(x, q)));
//			std::cout<< (w) << "," <<  (m_caches[w].calc(x, q)) << std::endl;
		}
		
		Stats stat = std::accumulate(fq.begin(), fq.end(), Stats());
		double slope = stat.slope();
//		std::cout << "q:" << q;
//		std::cout << "Hq:" << slope;

		Hq.push_back(slope);
//		std::cout << ",tq:" << slope*q - 1.0 <<std::endl;
		tq.push_back(slope*q - 1.0);
	}

	for (unsigned int i = 0; i < m_q.size() ; i++)
	{
		if (i < m_q.size() - 1)
		{
			double hq = (tq[i + 1] - tq[i]) / (m_q[i + 1] - m_q[i]);
			double dq = m_q[i] * hq - tq[i];
//			std::cout << "q:" << m_q[i];
//			std::cout << "hq:" <<hq;
//			std::cout << ",dq:" << dq << std::endl;
			ResultType rslt = ResultType(m_q[i], Hq[i], tq[i], dq, hq);
			m_results.push_back(std::move(rslt));
		}
		else
		{
			ResultType rslt = ResultType(m_q[i], Hq[i], tq[i], 0, 0);
			m_results.push_back(std::move(rslt));
		}

	}
	return m_results.size();
}

bool CMFDFA::get_results(
	unsigned int idx, 
	double & q,
	double & Hq,
	double & tq, 
	double & Dq,
	double & hq
) const
{
	if (m_results.size() <= idx) return false;
	q = m_results[idx].q;
	Hq = m_results[idx].Hq;
	tq = m_results[idx].tq;
	Dq = m_results[idx].Dq;
	hq = m_results[idx].hq;

	return true;
}


