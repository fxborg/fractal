#include <Windows.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <string>
#include <locale>


struct tick_type {
	time_t time;
	float bid;
	float ask;
	float bid_vol;
	float ask_vol;
};


int copy(const std::string & src, const std::string & dist,const float threshold)
{
	//---
	std::cout << "Threshold:" << threshold << std::endl;
	//---
	//---
	float prev_price = 0.0;
	int prev_hour = -1;
	//---
	std::ifstream fin(src);
	if (fin.bad()) {
		std::cout << "File Open Error:" << src  << std::endl;
		return 1;
	}
	std::ofstream fask;
	fask.open((dist+".Ask.txt").c_str());
	if (fask.bad())
	{
		std::cout << "File Open Error:" << dist <<".Ask.txt"<< std::endl;
		return 1;
	}
	fask.clear();
	std::cout << "writing :" << dist << ".Ask.txt" << std::endl;

	std::ofstream fbid;
	fbid.open((dist+".Bid.txt").c_str());
	if (fbid.bad())
	{
		std::cout << "File Open Error:" << dist << ".Bid.txt" << std::endl;
		return 1;
	}

	fbid.clear();
	std::cout << "writing :" << dist << ".Bid.txt" << std::endl;

	std::ofstream fmid;
	fmid.open((dist + ".Last.txt").c_str());
	if (fmid.bad())
	{
		std::cout << "File Open Error:" << dist << ".Last.txt" << std::endl;
		return 1;
	}

	fmid.clear();
	std::cout << "writing :" << dist << ".Last.txt" << std::endl;
	//---

	std::string str;
	int n = 0;
	while (std::getline(fin, str))
	{
		if (++n % 100000 == 0) std::cout << ".";
		struct tm tm = {0};
		tick_type tick;
		int msec;
		int res = sscanf_s(str.c_str(), "%4d.%2d.%2d %2d:%2d:%2d.%3d,%f,%f,%f,%f",
			&tm.tm_year,
			&tm.tm_mon,
			&tm.tm_mday,
			&tm.tm_hour,
			&tm.tm_min,
			&tm.tm_sec,
			&msec,
			&tick.ask,
			&tick.bid,
			&tick.ask_vol,
			&tick.bid_vol);
	
		if(res!=11){
			std::cout << "(Err)-->" << str << std::endl;
			continue;
		}
		// create tick data
		tm.tm_year -= 1900;
		tm.tm_mon -= 1;
		tick.time = mktime(&tm);
		// check time
		int hour = int(tick.time / 3600);
		float price = (tick.bid + tick.ask)*0.5f;
		// check price
		if (threshold > std::abs(price - prev_price))
		{
			if (prev_hour == hour) continue;
			else prev_hour = hour;
		}
		prev_price = price;

		char stime[20];
		strftime(stime, sizeof(stime), "%Y%m%d %H%M%S", std::localtime(&tick.time));
		char msec_str[4];
		sprintf_s(msec_str, sizeof(msec_str), "%03d", msec);
		fask << stime << " " << msec_str << "0000;" << tick.ask << ";" << max(1,int(tick.ask_vol)) << std::endl;
		fbid << stime << " " << msec_str << "0000;" << tick.bid << ";" << max(1, int(tick.bid_vol)) << std::endl;
		fmid << stime << " " << msec_str << "0000;" << (tick.ask+tick.bid)*0.5F << ";" << max(1, int(tick.ask_vol+tick.bid_vol)) << std::endl;
	}

	fin.close();
	fask.flush();
	fask.close();
	fbid.flush();
	fbid.close();
	fmid.flush();
	fmid.close();
	std::cout << "done." << std::endl;

	return 0;
}

int main(int argc, char *argv[])
{
	float threshold = 0.0001f;
	std::string src_path;
	std::string dist_path;
	if (argc != 4)
	{
		std::cout << "parameter count does not match." << std::endl;
		std::cout << "  ticoptimizer <src> <dist> <threshold>" << std::endl;
		return 2;
	}
	else
	{
		src_path = argv[1];
		dist_path = argv[2];
		threshold = std::stof(argv[3]);

	}
	return copy(src_path, dist_path,threshold);
}