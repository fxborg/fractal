#include <numeric>
#include <vector> 
#include <deque> 
#include <map> 
#include <algorithm>
#include <iostream>

class CRmsCache
{
public:
	CRmsCache();
	explicit CRmsCache(const unsigned int window, const unsigned int length); 
	void set(const int x, const double rms); 
	double calc(const unsigned int x ,const double q) const; 
	double calc_mono_fractal(const unsigned int x) const;
	double calc_multi_fractal(const unsigned int x, const double q) const;
private:
	const unsigned int m_window_size; 
	const unsigned int m_max_size;
	std::deque<std::map<unsigned int, double>> m_cache;
};

