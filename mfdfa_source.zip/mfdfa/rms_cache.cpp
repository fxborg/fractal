#include "rms_cache.h"

CRmsCache::CRmsCache():
	m_window_size(0),
	m_max_size(0),
	m_cache(0)
	{}

CRmsCache::CRmsCache(const unsigned int window_size=0, const unsigned int length=0) :
	m_window_size(window_size),
	m_max_size(int(length/window_size)),
	m_cache(window_size)
{}

void CRmsCache::set(const int x, const double rms)
{
	int mod = x % m_window_size;
	m_cache[mod][x] = rms;
	while (m_cache[mod].size() > m_max_size)
	{
		m_cache[mod].erase(m_cache[mod].begin());
	}
}

double CRmsCache::calc(const unsigned int x,const double q) const
{

	if (q == 0)
		return calc_mono_fractal(x);
	else
		return calc_multi_fractal(x, q);
}

double CRmsCache::calc_multi_fractal(const unsigned int x, const double q) const
{
	int mod = x % m_window_size;
	if (m_cache[mod].size() < 1) return 0.0;
	double result = 0.0;
	for (auto it = m_cache[mod].begin(); it != m_cache[mod].end(); it++)
	{
		result += std::pow(it->second, (q / 2));
	}
	return std::pow(result/m_cache[mod].size(),(1/q));
}

double CRmsCache::calc_mono_fractal(const unsigned int x) const
{
	int mod = x % m_window_size;
	if (m_cache[mod].size() < 1) return 0.0;
	double result = 0.0;
	for (auto it = m_cache[mod].begin(); it != m_cache[mod].end(); it++)
	{
		result += std::log(it->second);
	}
	return exp(0.5*(result/m_cache[mod].size()));
}



