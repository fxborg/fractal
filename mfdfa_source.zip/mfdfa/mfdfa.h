#define EXPORT  extern "C" // __declspec(dllexport)  
#include <deque> 
#include <vector> 
#include <unordered_map>
#include <numeric>
#include <cmath>
#include "series.h"
#include "rms_cache.h"
class CMFDFA
{
public:
	// �R���X�g���N�^
	explicit CMFDFA(
		const unsigned int length,
		const double scale_step,
		const unsigned  int scale_min,
		const unsigned  int scale_max,
		const double q_step,
		const double q_min,
		const double q_max
		);

	int push(const int x, const double y, const time_t t0, const time_t t1);

	int calculate();

	bool get_results(unsigned int idx, double &q, double &a, double &v) const;

private:
	const unsigned int m_length;
	CSeries m_series;
	std::vector<unsigned int> m_segments;
	std::vector<double> m_q;
	std::unordered_map<unsigned int, CRmsCache> m_caches;
	std::unordered_map<unsigned int, std::pair<unsigned int, Stats>> m_buffers;
	std::vector<std::vector< Stats>> m_results;

};

//--- �C���X�^���X�𐶐�
EXPORT CMFDFA * __stdcall Create(
	const unsigned int length,
	const double scale_step, 
	const unsigned int scale_min,
	const unsigned int scale_max,
	const double q_step,
	const double q_min,
	const double q_max);

//--- �C���X�^���X��j��
EXPORT void __stdcall Destroy(CMFDFA* instance);
//--- �C���X�^���X�o�R��push���\�b�h���R�[��
EXPORT int __stdcall Push(CMFDFA* instance, const int x, const double y, const time_t t0, const time_t t1);
//--- �\���l���v�Z
EXPORT int __stdcall Calculate(CMFDFA* instance);
EXPORT bool __stdcall GetResults(CMFDFA* instance, unsigned int idx, double &q, double &a, double &v);

